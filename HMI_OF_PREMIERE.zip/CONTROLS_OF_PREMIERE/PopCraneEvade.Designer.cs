﻿namespace CONTROLS_OF_PREMIERE
{
    partial class PopCraneEvade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSetEvade = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSend2SVR = new System.Windows.Forms.Button();
            this.btnCance2SVR = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.ComboBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.chkAfterJob = new System.Windows.Forms.CheckBox();
            this.chkRightNow = new System.Windows.Forms.CheckBox();
            this.chkXdec = new System.Windows.Forms.CheckBox();
            this.chkXinc = new System.Windows.Forms.CheckBox();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtDirection = new System.Windows.Forms.TextBox();
            this.txtEvadeX = new System.Windows.Forms.TextBox();
            this.txtReqEvadeX = new System.Windows.Forms.TextBox();
            this.txtOriSender = new System.Windows.Forms.TextBox();
            this.txtSender = new System.Windows.Forms.TextBox();
            this.txtCraneNO = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lab1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 498);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 3);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 449F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(409, 504);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.txtStatus);
            this.panel2.Controls.Add(this.btnRefresh);
            this.panel2.Controls.Add(this.chkAfterJob);
            this.panel2.Controls.Add(this.chkRightNow);
            this.panel2.Controls.Add(this.chkXdec);
            this.panel2.Controls.Add(this.chkXinc);
            this.panel2.Controls.Add(this.txtType);
            this.panel2.Controls.Add(this.txtDirection);
            this.panel2.Controls.Add(this.txtEvadeX);
            this.panel2.Controls.Add(this.txtReqEvadeX);
            this.panel2.Controls.Add(this.txtOriSender);
            this.panel2.Controls.Add(this.txtSender);
            this.panel2.Controls.Add(this.txtCraneNO);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lab1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(3, 49);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 443);
            this.panel2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSetEvade);
            this.groupBox2.Controls.Add(this.btnClear);
            this.groupBox2.Location = new System.Drawing.Point(215, 356);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(167, 70);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DB";
            // 
            // btnSetEvade
            // 
            this.btnSetEvade.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnSetEvade.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSetEvade.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSetEvade.Location = new System.Drawing.Point(3, 17);
            this.btnSetEvade.Name = "btnSetEvade";
            this.btnSetEvade.Size = new System.Drawing.Size(80, 50);
            this.btnSetEvade.TabIndex = 6;
            this.btnSetEvade.Text = "设定";
            this.btnSetEvade.UseVisualStyleBackColor = false;
            this.btnSetEvade.Click += new System.EventHandler(this.btnSetEvade_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnClear.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnClear.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnClear.Location = new System.Drawing.Point(84, 17);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 50);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "清空";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSend2SVR);
            this.groupBox1.Controls.Add(this.btnCance2SVR);
            this.groupBox1.Location = new System.Drawing.Point(18, 356);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(167, 70);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "tag";
            // 
            // btnSend2SVR
            // 
            this.btnSend2SVR.BackColor = System.Drawing.Color.LightBlue;
            this.btnSend2SVR.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend2SVR.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSend2SVR.Location = new System.Drawing.Point(4, 17);
            this.btnSend2SVR.Name = "btnSend2SVR";
            this.btnSend2SVR.Size = new System.Drawing.Size(80, 50);
            this.btnSend2SVR.TabIndex = 4;
            this.btnSend2SVR.Text = "发送";
            this.btnSend2SVR.UseVisualStyleBackColor = false;
            this.btnSend2SVR.Click += new System.EventHandler(this.btnSend2SVR_Click);
            // 
            // btnCance2SVR
            // 
            this.btnCance2SVR.BackColor = System.Drawing.Color.LightBlue;
            this.btnCance2SVR.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCance2SVR.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnCance2SVR.Location = new System.Drawing.Point(84, 17);
            this.btnCance2SVR.Name = "btnCance2SVR";
            this.btnCance2SVR.Size = new System.Drawing.Size(80, 50);
            this.btnCance2SVR.TabIndex = 8;
            this.btnCance2SVR.Text = "取消";
            this.btnCance2SVR.UseVisualStyleBackColor = false;
            this.btnCance2SVR.Click += new System.EventHandler(this.btnCance2SVR_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtStatus.FormattingEnabled = true;
            this.txtStatus.Items.AddRange(new object[] {
            "EMPTY",
            "TO_DO",
            "EXCUTING",
            "FINISHED"});
            this.txtStatus.Location = new System.Drawing.Point(119, 312);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(121, 24);
            this.txtStatus.TabIndex = 8;
            this.txtStatus.SelectedIndexChanged += new System.EventHandler(this.txtStatus_SelectedIndexChanged);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.SystemColors.Control;
            this.btnRefresh.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnRefresh.Location = new System.Drawing.Point(266, 79);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(86, 67);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "刷新";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // chkAfterJob
            // 
            this.chkAfterJob.AutoSize = true;
            this.chkAfterJob.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chkAfterJob.Location = new System.Drawing.Point(318, 272);
            this.chkAfterJob.Name = "chkAfterJob";
            this.chkAfterJob.Size = new System.Drawing.Size(61, 20);
            this.chkAfterJob.TabIndex = 12;
            this.chkAfterJob.Text = "关后";
            this.chkAfterJob.UseVisualStyleBackColor = true;
            this.chkAfterJob.CheckedChanged += new System.EventHandler(this.chkAfterJob_CheckedChanged);
            // 
            // chkRightNow
            // 
            this.chkRightNow.AutoSize = true;
            this.chkRightNow.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chkRightNow.Location = new System.Drawing.Point(236, 272);
            this.chkRightNow.Name = "chkRightNow";
            this.chkRightNow.Size = new System.Drawing.Size(61, 20);
            this.chkRightNow.TabIndex = 10;
            this.chkRightNow.Text = "立即";
            this.chkRightNow.UseVisualStyleBackColor = true;
            this.chkRightNow.CheckedChanged += new System.EventHandler(this.chkRightNow_CheckedChanged);
            // 
            // chkXdec
            // 
            this.chkXdec.AutoSize = true;
            this.chkXdec.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chkXdec.Location = new System.Drawing.Point(318, 230);
            this.chkXdec.Name = "chkXdec";
            this.chkXdec.Size = new System.Drawing.Size(70, 20);
            this.chkXdec.TabIndex = 11;
            this.chkXdec.Text = "X负向";
            this.chkXdec.UseVisualStyleBackColor = true;
            this.chkXdec.CheckedChanged += new System.EventHandler(this.chkXdec_CheckedChanged);
            // 
            // chkXinc
            // 
            this.chkXinc.AutoSize = true;
            this.chkXinc.BackColor = System.Drawing.Color.Transparent;
            this.chkXinc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.chkXinc.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chkXinc.Location = new System.Drawing.Point(236, 230);
            this.chkXinc.Name = "chkXinc";
            this.chkXinc.Size = new System.Drawing.Size(70, 20);
            this.chkXinc.TabIndex = 9;
            this.chkXinc.Text = "X正向";
            this.chkXinc.UseVisualStyleBackColor = false;
            this.chkXinc.CheckedChanged += new System.EventHandler(this.chkXinc_CheckedChanged);
            // 
            // txtType
            // 
            this.txtType.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtType.Location = new System.Drawing.Point(119, 270);
            this.txtType.Name = "txtType";
            this.txtType.ReadOnly = true;
            this.txtType.Size = new System.Drawing.Size(100, 26);
            this.txtType.TabIndex = 7;
            // 
            // txtDirection
            // 
            this.txtDirection.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtDirection.Location = new System.Drawing.Point(119, 228);
            this.txtDirection.Name = "txtDirection";
            this.txtDirection.ReadOnly = true;
            this.txtDirection.Size = new System.Drawing.Size(100, 26);
            this.txtDirection.TabIndex = 6;
            // 
            // txtEvadeX
            // 
            this.txtEvadeX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtEvadeX.Location = new System.Drawing.Point(119, 186);
            this.txtEvadeX.Name = "txtEvadeX";
            this.txtEvadeX.Size = new System.Drawing.Size(100, 26);
            this.txtEvadeX.TabIndex = 5;
            // 
            // txtReqEvadeX
            // 
            this.txtReqEvadeX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtReqEvadeX.Location = new System.Drawing.Point(119, 144);
            this.txtReqEvadeX.Name = "txtReqEvadeX";
            this.txtReqEvadeX.Size = new System.Drawing.Size(100, 26);
            this.txtReqEvadeX.TabIndex = 4;
            // 
            // txtOriSender
            // 
            this.txtOriSender.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtOriSender.Location = new System.Drawing.Point(119, 102);
            this.txtOriSender.Name = "txtOriSender";
            this.txtOriSender.Size = new System.Drawing.Size(100, 26);
            this.txtOriSender.TabIndex = 3;
            // 
            // txtSender
            // 
            this.txtSender.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtSender.Location = new System.Drawing.Point(119, 60);
            this.txtSender.Name = "txtSender";
            this.txtSender.Size = new System.Drawing.Size(100, 26);
            this.txtSender.TabIndex = 2;
            // 
            // txtCraneNO
            // 
            this.txtCraneNO.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCraneNO.Location = new System.Drawing.Point(119, 18);
            this.txtCraneNO.Name = "txtCraneNO";
            this.txtCraneNO.ReadOnly = true;
            this.txtCraneNO.Size = new System.Drawing.Size(100, 26);
            this.txtCraneNO.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(71, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "状态";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(71, 274);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "类型";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(71, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "方向";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(28, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "允许避让X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(20, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "最初发起者";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(28, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "要求避让X";
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab1.Location = new System.Drawing.Point(54, 64);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(59, 16);
            this.lab1.TabIndex = 0;
            this.lab1.Text = "发送者";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(54, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "行车号";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(403, 40);
            this.panel3.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(146, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "避让信息";
            // 
            // PopCraneEvade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 504);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.Name = "PopCraneEvade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "行车避让";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSetEvade;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkAfterJob;
        private System.Windows.Forms.CheckBox chkRightNow;
        private System.Windows.Forms.CheckBox chkXdec;
        private System.Windows.Forms.CheckBox chkXinc;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtEvadeX;
        private System.Windows.Forms.TextBox txtReqEvadeX;
        private System.Windows.Forms.TextBox txtOriSender;
        private System.Windows.Forms.TextBox txtSender;
        private System.Windows.Forms.TextBox txtCraneNO;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDirection;
        private System.Windows.Forms.Button btnSend2SVR;
        private System.Windows.Forms.Button btnCance2SVR;
        private System.Windows.Forms.ComboBox txtStatus;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}