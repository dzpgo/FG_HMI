﻿namespace CONTROLS_OF_PREMIERE
{
    partial class ConCraneStatusPanel
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.cmdComputerOrderSetting = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.TXT_TEMPERATURE = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel30 = new System.Windows.Forms.Panel();
            this.cmdDownLoadPlan = new System.Windows.Forms.Button();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btnEvade = new System.Windows.Forms.Button();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txt_R_e = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.txt_Z_e = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txt_Y_e = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txt_X_e = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txt_HeartBeat = new System.Windows.Forms.TextBox();
            this.panel35 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel36 = new System.Windows.Forms.Panel();
            this.light_EMG_STOP = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.panel37 = new System.Windows.Forms.Panel();
            this.light_HAS_COIL = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.light_ZDIR_N = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.panel39 = new System.Windows.Forms.Panel();
            this.light_ZDIR_P = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.panel40 = new System.Windows.Forms.Panel();
            this.light_YDIR_N = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.panel41 = new System.Windows.Forms.Panel();
            this.light_YDIR_P = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.panel42 = new System.Windows.Forms.Panel();
            this.light_XDIR_N = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.panel43 = new System.Windows.Forms.Panel();
            this.light_XDIR_P = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.panel44 = new System.Windows.Forms.Panel();
            this.light_TASK_EXCUTING = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.panel45 = new System.Windows.Forms.Panel();
            this.light_ASK_PLAN = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.panel46 = new System.Windows.Forms.Panel();
            this.light_CONTROL_MODE = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.panel47 = new System.Windows.Forms.Panel();
            this.light_READY = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txt_CRANE_STATUS_DESC = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.txt_CRANE_STATUS = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txt_PLAN_DOWN_Z = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txt_PLAN_DOWN_Y = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txt_PLAN_DOWN_X = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txt_PLAN_UP_Z = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_PLAN_UP_Y = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_PLAN_UP_X = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txt_ORDER_ID = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txt_CLAMP_WIDTH_ACT = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txt_ROTATE_ANGLE_ACT = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_WEIGHT_LOADED = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_ZSPEED = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_YSPEED = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.txt_XSPEED = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txt_ZACT = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_YACT = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_XACT = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_CONTROL_MODE = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.text_CraneNO = new System.Windows.Forms.TextBox();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.cmd_Auto = new System.Windows.Forms.Button();
            this.panel50 = new System.Windows.Forms.Panel();
            this.cmd_Manu = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.cmd_Reset = new System.Windows.Forms.Button();
            this.panel49 = new System.Windows.Forms.Panel();
            this.cmd_EmergencyStop = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.timer_AutoReset = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel25, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel26, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel27, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(376, 742);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel28, 0, 19);
            this.tableLayoutPanel4.Controls.Add(this.panel29, 0, 18);
            this.tableLayoutPanel4.Controls.Add(this.panel30, 0, 17);
            this.tableLayoutPanel4.Controls.Add(this.panel31, 0, 16);
            this.tableLayoutPanel4.Controls.Add(this.panel32, 0, 15);
            this.tableLayoutPanel4.Controls.Add(this.panel33, 0, 14);
            this.tableLayoutPanel4.Controls.Add(this.panel34, 0, 13);
            this.tableLayoutPanel4.Controls.Add(this.panel35, 0, 12);
            this.tableLayoutPanel4.Controls.Add(this.panel36, 0, 11);
            this.tableLayoutPanel4.Controls.Add(this.panel37, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.panel38, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.panel39, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.panel40, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.panel41, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.panel42, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.panel43, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.panel44, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.panel45, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.panel46, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.panel47, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 40);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 20;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(144, 624);
            this.tableLayoutPanel4.TabIndex = 5;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.cmdComputerOrderSetting);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(3, 592);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(138, 29);
            this.panel28.TabIndex = 19;
            // 
            // cmdComputerOrderSetting
            // 
            this.cmdComputerOrderSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmdComputerOrderSetting.Location = new System.Drawing.Point(0, 0);
            this.cmdComputerOrderSetting.Name = "cmdComputerOrderSetting";
            this.cmdComputerOrderSetting.Size = new System.Drawing.Size(138, 29);
            this.cmdComputerOrderSetting.TabIndex = 0;
            this.cmdComputerOrderSetting.Text = "Computer Order";
            this.cmdComputerOrderSetting.UseVisualStyleBackColor = true;
            this.cmdComputerOrderSetting.Click += new System.EventHandler(this.cmdComputerOrder_Click);
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.TXT_TEMPERATURE);
            this.panel29.Controls.Add(this.textBox2);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(3, 561);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(138, 25);
            this.panel29.TabIndex = 18;
            // 
            // TXT_TEMPERATURE
            // 
            this.TXT_TEMPERATURE.BackColor = System.Drawing.Color.White;
            this.TXT_TEMPERATURE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXT_TEMPERATURE.Dock = System.Windows.Forms.DockStyle.Left;
            this.TXT_TEMPERATURE.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TXT_TEMPERATURE.Location = new System.Drawing.Point(87, 0);
            this.TXT_TEMPERATURE.Margin = new System.Windows.Forms.Padding(2);
            this.TXT_TEMPERATURE.Name = "TXT_TEMPERATURE";
            this.TXT_TEMPERATURE.ReadOnly = true;
            this.TXT_TEMPERATURE.Size = new System.Drawing.Size(61, 18);
            this.TXT_TEMPERATURE.TabIndex = 61;
            this.TXT_TEMPERATURE.Text = "999999";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox2.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(0, 0);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(87, 18);
            this.textBox2.TabIndex = 57;
            this.textBox2.Text = "钢卷温度 ";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.cmdDownLoadPlan);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(3, 530);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(138, 25);
            this.panel30.TabIndex = 17;
            // 
            // cmdDownLoadPlan
            // 
            this.cmdDownLoadPlan.Dock = System.Windows.Forms.DockStyle.Right;
            this.cmdDownLoadPlan.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmdDownLoadPlan.Location = new System.Drawing.Point(3, 0);
            this.cmdDownLoadPlan.Name = "cmdDownLoadPlan";
            this.cmdDownLoadPlan.Size = new System.Drawing.Size(135, 25);
            this.cmdDownLoadPlan.TabIndex = 4;
            this.cmdDownLoadPlan.Text = "下达指令";
            this.cmdDownLoadPlan.UseVisualStyleBackColor = true;
            this.cmdDownLoadPlan.Click += new System.EventHandler(this.cmdDownLoadPlan_Click_1);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.btnEvade);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(3, 499);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(138, 25);
            this.panel31.TabIndex = 16;
            // 
            // btnEvade
            // 
            this.btnEvade.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnEvade.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnEvade.Location = new System.Drawing.Point(3, 0);
            this.btnEvade.Name = "btnEvade";
            this.btnEvade.Size = new System.Drawing.Size(135, 25);
            this.btnEvade.TabIndex = 6;
            this.btnEvade.Text = "避让设定";
            this.btnEvade.UseVisualStyleBackColor = true;
            this.btnEvade.Click += new System.EventHandler(this.btnEvade_Click);
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txt_R_e);
            this.panel32.Controls.Add(this.textBox9);
            this.panel32.Controls.Add(this.txt_Z_e);
            this.panel32.Controls.Add(this.textBox11);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(3, 468);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(138, 25);
            this.panel32.TabIndex = 15;
            // 
            // txt_R_e
            // 
            this.txt_R_e.BackColor = System.Drawing.Color.LightGreen;
            this.txt_R_e.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_R_e.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_R_e.Location = new System.Drawing.Point(104, 0);
            this.txt_R_e.Margin = new System.Windows.Forms.Padding(2);
            this.txt_R_e.Name = "txt_R_e";
            this.txt_R_e.Size = new System.Drawing.Size(10, 22);
            this.txt_R_e.TabIndex = 65;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Control;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox9.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox9.Location = new System.Drawing.Point(53, 0);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(51, 18);
            this.textBox9.TabIndex = 64;
            this.textBox9.Text = " R_e ";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_Z_e
            // 
            this.txt_Z_e.BackColor = System.Drawing.Color.LightGreen;
            this.txt_Z_e.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_Z_e.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_Z_e.Location = new System.Drawing.Point(43, 0);
            this.txt_Z_e.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Z_e.Name = "txt_Z_e";
            this.txt_Z_e.Size = new System.Drawing.Size(10, 22);
            this.txt_Z_e.TabIndex = 63;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.Control;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox11.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox11.Location = new System.Drawing.Point(0, 0);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(43, 18);
            this.textBox11.TabIndex = 62;
            this.textBox11.Text = "Z_e  ";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Controls.Add(this.txt_Y_e);
            this.panel33.Controls.Add(this.textBox7);
            this.panel33.Controls.Add(this.txt_X_e);
            this.panel33.Controls.Add(this.textBox4);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(3, 437);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(138, 25);
            this.panel33.TabIndex = 14;
            // 
            // txt_Y_e
            // 
            this.txt_Y_e.BackColor = System.Drawing.Color.LightGreen;
            this.txt_Y_e.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_Y_e.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_Y_e.Location = new System.Drawing.Point(104, 0);
            this.txt_Y_e.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Y_e.Name = "txt_Y_e";
            this.txt_Y_e.Size = new System.Drawing.Size(10, 22);
            this.txt_Y_e.TabIndex = 61;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox7.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(53, 0);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(51, 18);
            this.textBox7.TabIndex = 60;
            this.textBox7.Text = " Y_e ";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_X_e
            // 
            this.txt_X_e.BackColor = System.Drawing.Color.LightGreen;
            this.txt_X_e.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_X_e.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_X_e.Location = new System.Drawing.Point(43, 0);
            this.txt_X_e.Margin = new System.Windows.Forms.Padding(2);
            this.txt_X_e.Name = "txt_X_e";
            this.txt_X_e.Size = new System.Drawing.Size(10, 22);
            this.txt_X_e.TabIndex = 59;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox4.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(0, 0);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(43, 18);
            this.textBox4.TabIndex = 58;
            this.textBox4.Text = "X_e  ";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.txt_HeartBeat);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel34.Location = new System.Drawing.Point(3, 406);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(138, 25);
            this.panel34.TabIndex = 13;
            // 
            // txt_HeartBeat
            // 
            this.txt_HeartBeat.BackColor = System.Drawing.SystemColors.Control;
            this.txt_HeartBeat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_HeartBeat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_HeartBeat.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_HeartBeat.Location = new System.Drawing.Point(0, 0);
            this.txt_HeartBeat.Margin = new System.Windows.Forms.Padding(2);
            this.txt_HeartBeat.Name = "txt_HeartBeat";
            this.txt_HeartBeat.ReadOnly = true;
            this.txt_HeartBeat.Size = new System.Drawing.Size(138, 18);
            this.txt_HeartBeat.TabIndex = 59;
            this.txt_HeartBeat.Text = "999999";
            this.txt_HeartBeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.textBox1);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(3, 375);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(138, 25);
            this.panel35.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox1.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(104, 18);
            this.textBox1.TabIndex = 58;
            this.textBox1.Text = "心跳";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.light_EMG_STOP);
            this.panel36.Controls.Add(this.textBox26);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel36.Location = new System.Drawing.Point(3, 344);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(138, 25);
            this.panel36.TabIndex = 11;
            // 
            // light_EMG_STOP
            // 
            this.light_EMG_STOP.BackColor = System.Drawing.Color.LightGreen;
            this.light_EMG_STOP.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_EMG_STOP.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_EMG_STOP.Location = new System.Drawing.Point(104, 0);
            this.light_EMG_STOP.Margin = new System.Windows.Forms.Padding(2);
            this.light_EMG_STOP.Name = "light_EMG_STOP";
            this.light_EMG_STOP.Size = new System.Drawing.Size(10, 22);
            this.light_EMG_STOP.TabIndex = 57;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.Control;
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox26.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox26.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox26.Location = new System.Drawing.Point(0, 0);
            this.textBox26.Margin = new System.Windows.Forms.Padding(2);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(104, 18);
            this.textBox26.TabIndex = 56;
            this.textBox26.Text = "紧停  ";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.White;
            this.panel37.Controls.Add(this.light_HAS_COIL);
            this.panel37.Controls.Add(this.textBox25);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(3, 313);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(138, 25);
            this.panel37.TabIndex = 10;
            // 
            // light_HAS_COIL
            // 
            this.light_HAS_COIL.BackColor = System.Drawing.Color.LightGreen;
            this.light_HAS_COIL.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_HAS_COIL.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_HAS_COIL.Location = new System.Drawing.Point(104, 0);
            this.light_HAS_COIL.Margin = new System.Windows.Forms.Padding(2);
            this.light_HAS_COIL.Name = "light_HAS_COIL";
            this.light_HAS_COIL.Size = new System.Drawing.Size(10, 22);
            this.light_HAS_COIL.TabIndex = 57;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.White;
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox25.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox25.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox25.Location = new System.Drawing.Point(0, 0);
            this.textBox25.Margin = new System.Windows.Forms.Padding(2);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(104, 18);
            this.textBox25.TabIndex = 56;
            this.textBox25.Text = "有卷  ";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.light_ZDIR_N);
            this.panel38.Controls.Add(this.textBox24);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel38.Location = new System.Drawing.Point(3, 282);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(138, 25);
            this.panel38.TabIndex = 9;
            // 
            // light_ZDIR_N
            // 
            this.light_ZDIR_N.BackColor = System.Drawing.Color.LightGreen;
            this.light_ZDIR_N.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_ZDIR_N.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_ZDIR_N.Location = new System.Drawing.Point(104, 0);
            this.light_ZDIR_N.Margin = new System.Windows.Forms.Padding(2);
            this.light_ZDIR_N.Name = "light_ZDIR_N";
            this.light_ZDIR_N.Size = new System.Drawing.Size(10, 22);
            this.light_ZDIR_N.TabIndex = 57;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.SystemColors.Control;
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox24.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox24.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox24.Location = new System.Drawing.Point(0, 0);
            this.textBox24.Margin = new System.Windows.Forms.Padding(2);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(104, 18);
            this.textBox24.TabIndex = 56;
            this.textBox24.Text = "升降负向  ";
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.White;
            this.panel39.Controls.Add(this.light_ZDIR_P);
            this.panel39.Controls.Add(this.textBox23);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel39.Location = new System.Drawing.Point(3, 251);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(138, 25);
            this.panel39.TabIndex = 8;
            // 
            // light_ZDIR_P
            // 
            this.light_ZDIR_P.BackColor = System.Drawing.Color.LightGreen;
            this.light_ZDIR_P.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_ZDIR_P.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_ZDIR_P.Location = new System.Drawing.Point(104, 0);
            this.light_ZDIR_P.Margin = new System.Windows.Forms.Padding(2);
            this.light_ZDIR_P.Name = "light_ZDIR_P";
            this.light_ZDIR_P.Size = new System.Drawing.Size(10, 22);
            this.light_ZDIR_P.TabIndex = 57;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.White;
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox23.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox23.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox23.Location = new System.Drawing.Point(0, 0);
            this.textBox23.Margin = new System.Windows.Forms.Padding(2);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(104, 18);
            this.textBox23.TabIndex = 56;
            this.textBox23.Text = "升降正向  ";
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.light_YDIR_N);
            this.panel40.Controls.Add(this.textBox22);
            this.panel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel40.Location = new System.Drawing.Point(3, 220);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(138, 25);
            this.panel40.TabIndex = 7;
            // 
            // light_YDIR_N
            // 
            this.light_YDIR_N.BackColor = System.Drawing.Color.LightGreen;
            this.light_YDIR_N.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_YDIR_N.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_YDIR_N.Location = new System.Drawing.Point(104, 0);
            this.light_YDIR_N.Margin = new System.Windows.Forms.Padding(2);
            this.light_YDIR_N.Name = "light_YDIR_N";
            this.light_YDIR_N.Size = new System.Drawing.Size(10, 22);
            this.light_YDIR_N.TabIndex = 57;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.SystemColors.Control;
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox22.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox22.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox22.Location = new System.Drawing.Point(0, 0);
            this.textBox22.Margin = new System.Windows.Forms.Padding(2);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(104, 18);
            this.textBox22.TabIndex = 56;
            this.textBox22.Text = "小车负向  ";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Controls.Add(this.light_YDIR_P);
            this.panel41.Controls.Add(this.textBox21);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel41.Location = new System.Drawing.Point(3, 189);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(138, 25);
            this.panel41.TabIndex = 6;
            // 
            // light_YDIR_P
            // 
            this.light_YDIR_P.BackColor = System.Drawing.Color.LightGreen;
            this.light_YDIR_P.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_YDIR_P.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_YDIR_P.Location = new System.Drawing.Point(104, 0);
            this.light_YDIR_P.Margin = new System.Windows.Forms.Padding(2);
            this.light_YDIR_P.Name = "light_YDIR_P";
            this.light_YDIR_P.Size = new System.Drawing.Size(10, 22);
            this.light_YDIR_P.TabIndex = 57;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.White;
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox21.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox21.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox21.Location = new System.Drawing.Point(0, 0);
            this.textBox21.Margin = new System.Windows.Forms.Padding(2);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(104, 18);
            this.textBox21.TabIndex = 56;
            this.textBox21.Text = "小车正向  ";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.light_XDIR_N);
            this.panel42.Controls.Add(this.textBox19);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel42.Location = new System.Drawing.Point(3, 158);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(138, 25);
            this.panel42.TabIndex = 5;
            // 
            // light_XDIR_N
            // 
            this.light_XDIR_N.BackColor = System.Drawing.Color.LightGreen;
            this.light_XDIR_N.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_XDIR_N.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_XDIR_N.Location = new System.Drawing.Point(104, 0);
            this.light_XDIR_N.Margin = new System.Windows.Forms.Padding(2);
            this.light_XDIR_N.Name = "light_XDIR_N";
            this.light_XDIR_N.Size = new System.Drawing.Size(10, 22);
            this.light_XDIR_N.TabIndex = 57;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.Control;
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox19.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox19.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox19.Location = new System.Drawing.Point(0, 0);
            this.textBox19.Margin = new System.Windows.Forms.Padding(2);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(104, 18);
            this.textBox19.TabIndex = 56;
            this.textBox19.Text = "大车负向  ";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.White;
            this.panel43.Controls.Add(this.light_XDIR_P);
            this.panel43.Controls.Add(this.textBox18);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel43.Location = new System.Drawing.Point(3, 127);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(138, 25);
            this.panel43.TabIndex = 4;
            // 
            // light_XDIR_P
            // 
            this.light_XDIR_P.BackColor = System.Drawing.Color.LightGreen;
            this.light_XDIR_P.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_XDIR_P.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_XDIR_P.Location = new System.Drawing.Point(104, 0);
            this.light_XDIR_P.Margin = new System.Windows.Forms.Padding(2);
            this.light_XDIR_P.Name = "light_XDIR_P";
            this.light_XDIR_P.Size = new System.Drawing.Size(10, 22);
            this.light_XDIR_P.TabIndex = 57;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.White;
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox18.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox18.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox18.Location = new System.Drawing.Point(0, 0);
            this.textBox18.Margin = new System.Windows.Forms.Padding(2);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(104, 18);
            this.textBox18.TabIndex = 56;
            this.textBox18.Text = "大车正向  ";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.light_TASK_EXCUTING);
            this.panel44.Controls.Add(this.textBox17);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel44.Location = new System.Drawing.Point(3, 96);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(138, 25);
            this.panel44.TabIndex = 3;
            // 
            // light_TASK_EXCUTING
            // 
            this.light_TASK_EXCUTING.BackColor = System.Drawing.Color.LightGreen;
            this.light_TASK_EXCUTING.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_TASK_EXCUTING.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_TASK_EXCUTING.Location = new System.Drawing.Point(104, 0);
            this.light_TASK_EXCUTING.Margin = new System.Windows.Forms.Padding(2);
            this.light_TASK_EXCUTING.Name = "light_TASK_EXCUTING";
            this.light_TASK_EXCUTING.Size = new System.Drawing.Size(10, 22);
            this.light_TASK_EXCUTING.TabIndex = 57;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.Control;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox17.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox17.Location = new System.Drawing.Point(0, 0);
            this.textBox17.Margin = new System.Windows.Forms.Padding(2);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(104, 18);
            this.textBox17.TabIndex = 56;
            this.textBox17.Text = "指令执行中  ";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.White;
            this.panel45.Controls.Add(this.light_ASK_PLAN);
            this.panel45.Controls.Add(this.textBox16);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel45.Location = new System.Drawing.Point(3, 65);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(138, 25);
            this.panel45.TabIndex = 2;
            // 
            // light_ASK_PLAN
            // 
            this.light_ASK_PLAN.BackColor = System.Drawing.Color.LightGreen;
            this.light_ASK_PLAN.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_ASK_PLAN.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_ASK_PLAN.Location = new System.Drawing.Point(104, 0);
            this.light_ASK_PLAN.Margin = new System.Windows.Forms.Padding(2);
            this.light_ASK_PLAN.Name = "light_ASK_PLAN";
            this.light_ASK_PLAN.Size = new System.Drawing.Size(10, 22);
            this.light_ASK_PLAN.TabIndex = 57;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.White;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox16.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox16.Location = new System.Drawing.Point(0, 0);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(104, 18);
            this.textBox16.TabIndex = 56;
            this.textBox16.Text = "请求指令  ";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel46
            // 
            this.panel46.Controls.Add(this.light_CONTROL_MODE);
            this.panel46.Controls.Add(this.textBox15);
            this.panel46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel46.Location = new System.Drawing.Point(3, 34);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(138, 25);
            this.panel46.TabIndex = 1;
            // 
            // light_CONTROL_MODE
            // 
            this.light_CONTROL_MODE.BackColor = System.Drawing.Color.LightGreen;
            this.light_CONTROL_MODE.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_CONTROL_MODE.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_CONTROL_MODE.Location = new System.Drawing.Point(104, 0);
            this.light_CONTROL_MODE.Margin = new System.Windows.Forms.Padding(2);
            this.light_CONTROL_MODE.Name = "light_CONTROL_MODE";
            this.light_CONTROL_MODE.Size = new System.Drawing.Size(10, 22);
            this.light_CONTROL_MODE.TabIndex = 57;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.Control;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox15.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox15.Location = new System.Drawing.Point(0, 0);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(104, 18);
            this.textBox15.TabIndex = 56;
            this.textBox15.Text = "自动  ";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.White;
            this.panel47.Controls.Add(this.light_READY);
            this.panel47.Controls.Add(this.textBox20);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel47.Location = new System.Drawing.Point(3, 3);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(138, 25);
            this.panel47.TabIndex = 0;
            // 
            // light_READY
            // 
            this.light_READY.BackColor = System.Drawing.Color.LightGreen;
            this.light_READY.Dock = System.Windows.Forms.DockStyle.Left;
            this.light_READY.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.light_READY.Location = new System.Drawing.Point(104, 0);
            this.light_READY.Margin = new System.Windows.Forms.Padding(2);
            this.light_READY.Name = "light_READY";
            this.light_READY.Size = new System.Drawing.Size(10, 22);
            this.light_READY.TabIndex = 56;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.White;
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox20.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox20.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox20.Location = new System.Drawing.Point(0, 0);
            this.textBox20.Margin = new System.Windows.Forms.Padding(2);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(104, 18);
            this.textBox20.TabIndex = 55;
            this.textBox20.Text = "准备好  ";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel20, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.panel19, 0, 18);
            this.tableLayoutPanel2.Controls.Add(this.panel18, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.panel17, 0, 16);
            this.tableLayoutPanel2.Controls.Add(this.panel16, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.panel15, 0, 14);
            this.tableLayoutPanel2.Controls.Add(this.panel14, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.panel13, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.panel12, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.panel11, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.panel10, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.panel9, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.panel8, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.panel7, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.panel6, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(153, 40);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 20;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(220, 624);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.button1);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(3, 592);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(214, 29);
            this.panel20.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(214, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "报警查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.txt_CRANE_STATUS_DESC);
            this.panel19.Controls.Add(this.textBox48);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(3, 561);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(214, 25);
            this.panel19.TabIndex = 18;
            // 
            // txt_CRANE_STATUS_DESC
            // 
            this.txt_CRANE_STATUS_DESC.BackColor = System.Drawing.Color.White;
            this.txt_CRANE_STATUS_DESC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CRANE_STATUS_DESC.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_CRANE_STATUS_DESC.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_CRANE_STATUS_DESC.Location = new System.Drawing.Point(104, 0);
            this.txt_CRANE_STATUS_DESC.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CRANE_STATUS_DESC.Name = "txt_CRANE_STATUS_DESC";
            this.txt_CRANE_STATUS_DESC.ReadOnly = true;
            this.txt_CRANE_STATUS_DESC.Size = new System.Drawing.Size(104, 18);
            this.txt_CRANE_STATUS_DESC.TabIndex = 60;
            this.txt_CRANE_STATUS_DESC.Text = "999999";
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.Color.White;
            this.textBox48.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox48.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox48.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox48.Location = new System.Drawing.Point(0, 0);
            this.textBox48.Margin = new System.Windows.Forms.Padding(2);
            this.textBox48.Name = "textBox48";
            this.textBox48.ReadOnly = true;
            this.textBox48.Size = new System.Drawing.Size(104, 18);
            this.textBox48.TabIndex = 59;
            this.textBox48.Text = "  ";
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.txt_CRANE_STATUS);
            this.panel18.Controls.Add(this.textBox47);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(3, 530);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(214, 25);
            this.panel18.TabIndex = 17;
            // 
            // txt_CRANE_STATUS
            // 
            this.txt_CRANE_STATUS.BackColor = System.Drawing.SystemColors.Control;
            this.txt_CRANE_STATUS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CRANE_STATUS.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_CRANE_STATUS.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_CRANE_STATUS.Location = new System.Drawing.Point(104, 0);
            this.txt_CRANE_STATUS.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CRANE_STATUS.Name = "txt_CRANE_STATUS";
            this.txt_CRANE_STATUS.ReadOnly = true;
            this.txt_CRANE_STATUS.Size = new System.Drawing.Size(104, 18);
            this.txt_CRANE_STATUS.TabIndex = 60;
            this.txt_CRANE_STATUS.Text = "999999";
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.Control;
            this.textBox47.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox47.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox47.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox47.Location = new System.Drawing.Point(0, 0);
            this.textBox47.Margin = new System.Windows.Forms.Padding(2);
            this.textBox47.Name = "textBox47";
            this.textBox47.ReadOnly = true;
            this.textBox47.Size = new System.Drawing.Size(104, 18);
            this.textBox47.TabIndex = 59;
            this.textBox47.Text = "行车状态  ";
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.txt_PLAN_DOWN_Z);
            this.panel17.Controls.Add(this.textBox46);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(3, 499);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(214, 25);
            this.panel17.TabIndex = 16;
            // 
            // txt_PLAN_DOWN_Z
            // 
            this.txt_PLAN_DOWN_Z.BackColor = System.Drawing.Color.White;
            this.txt_PLAN_DOWN_Z.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_DOWN_Z.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_DOWN_Z.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_DOWN_Z.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_DOWN_Z.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_DOWN_Z.Name = "txt_PLAN_DOWN_Z";
            this.txt_PLAN_DOWN_Z.ReadOnly = true;
            this.txt_PLAN_DOWN_Z.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_DOWN_Z.TabIndex = 59;
            this.txt_PLAN_DOWN_Z.Text = "999999";
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.Color.White;
            this.textBox46.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox46.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox46.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox46.Location = new System.Drawing.Point(0, 0);
            this.textBox46.Margin = new System.Windows.Forms.Padding(2);
            this.textBox46.Name = "textBox46";
            this.textBox46.ReadOnly = true;
            this.textBox46.Size = new System.Drawing.Size(104, 18);
            this.textBox46.TabIndex = 58;
            this.textBox46.Text = "落关Z  ";
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txt_PLAN_DOWN_Y);
            this.panel16.Controls.Add(this.textBox45);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(3, 468);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(214, 25);
            this.panel16.TabIndex = 15;
            // 
            // txt_PLAN_DOWN_Y
            // 
            this.txt_PLAN_DOWN_Y.BackColor = System.Drawing.SystemColors.Control;
            this.txt_PLAN_DOWN_Y.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_DOWN_Y.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_DOWN_Y.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_DOWN_Y.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_DOWN_Y.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_DOWN_Y.Name = "txt_PLAN_DOWN_Y";
            this.txt_PLAN_DOWN_Y.ReadOnly = true;
            this.txt_PLAN_DOWN_Y.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_DOWN_Y.TabIndex = 59;
            this.txt_PLAN_DOWN_Y.Text = "999999";
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.Control;
            this.textBox45.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox45.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox45.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox45.Location = new System.Drawing.Point(0, 0);
            this.textBox45.Margin = new System.Windows.Forms.Padding(2);
            this.textBox45.Name = "textBox45";
            this.textBox45.ReadOnly = true;
            this.textBox45.Size = new System.Drawing.Size(104, 18);
            this.textBox45.TabIndex = 58;
            this.textBox45.Text = "落关Y  ";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.txt_PLAN_DOWN_X);
            this.panel15.Controls.Add(this.textBox44);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(3, 437);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(214, 25);
            this.panel15.TabIndex = 14;
            // 
            // txt_PLAN_DOWN_X
            // 
            this.txt_PLAN_DOWN_X.BackColor = System.Drawing.Color.White;
            this.txt_PLAN_DOWN_X.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_DOWN_X.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_DOWN_X.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_DOWN_X.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_DOWN_X.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_DOWN_X.Name = "txt_PLAN_DOWN_X";
            this.txt_PLAN_DOWN_X.ReadOnly = true;
            this.txt_PLAN_DOWN_X.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_DOWN_X.TabIndex = 58;
            this.txt_PLAN_DOWN_X.Text = "999999";
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.Color.White;
            this.textBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox44.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox44.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox44.Location = new System.Drawing.Point(0, 0);
            this.textBox44.Margin = new System.Windows.Forms.Padding(2);
            this.textBox44.Name = "textBox44";
            this.textBox44.ReadOnly = true;
            this.textBox44.Size = new System.Drawing.Size(104, 18);
            this.textBox44.TabIndex = 57;
            this.textBox44.Text = "落关X  ";
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txt_PLAN_UP_Z);
            this.panel14.Controls.Add(this.textBox43);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 406);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(214, 25);
            this.panel14.TabIndex = 13;
            // 
            // txt_PLAN_UP_Z
            // 
            this.txt_PLAN_UP_Z.BackColor = System.Drawing.SystemColors.Control;
            this.txt_PLAN_UP_Z.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_UP_Z.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_UP_Z.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_UP_Z.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_UP_Z.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_UP_Z.Name = "txt_PLAN_UP_Z";
            this.txt_PLAN_UP_Z.ReadOnly = true;
            this.txt_PLAN_UP_Z.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_UP_Z.TabIndex = 58;
            this.txt_PLAN_UP_Z.Text = "999999";
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.Control;
            this.textBox43.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox43.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox43.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox43.Location = new System.Drawing.Point(0, 0);
            this.textBox43.Margin = new System.Windows.Forms.Padding(2);
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.Size = new System.Drawing.Size(104, 18);
            this.textBox43.TabIndex = 57;
            this.textBox43.Text = "起吊Z  ";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.txt_PLAN_UP_Y);
            this.panel13.Controls.Add(this.textBox42);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(3, 375);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(214, 25);
            this.panel13.TabIndex = 12;
            // 
            // txt_PLAN_UP_Y
            // 
            this.txt_PLAN_UP_Y.BackColor = System.Drawing.Color.White;
            this.txt_PLAN_UP_Y.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_UP_Y.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_UP_Y.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_UP_Y.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_UP_Y.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_UP_Y.Name = "txt_PLAN_UP_Y";
            this.txt_PLAN_UP_Y.ReadOnly = true;
            this.txt_PLAN_UP_Y.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_UP_Y.TabIndex = 58;
            this.txt_PLAN_UP_Y.Text = "999999";
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.Color.White;
            this.textBox42.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox42.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox42.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox42.Location = new System.Drawing.Point(0, 0);
            this.textBox42.Margin = new System.Windows.Forms.Padding(2);
            this.textBox42.Name = "textBox42";
            this.textBox42.ReadOnly = true;
            this.textBox42.Size = new System.Drawing.Size(104, 18);
            this.textBox42.TabIndex = 57;
            this.textBox42.Text = "起吊Y  ";
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.txt_PLAN_UP_X);
            this.panel12.Controls.Add(this.textBox41);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 344);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(214, 25);
            this.panel12.TabIndex = 11;
            // 
            // txt_PLAN_UP_X
            // 
            this.txt_PLAN_UP_X.BackColor = System.Drawing.SystemColors.Control;
            this.txt_PLAN_UP_X.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_PLAN_UP_X.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_PLAN_UP_X.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_PLAN_UP_X.Location = new System.Drawing.Point(104, 0);
            this.txt_PLAN_UP_X.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PLAN_UP_X.Name = "txt_PLAN_UP_X";
            this.txt_PLAN_UP_X.ReadOnly = true;
            this.txt_PLAN_UP_X.Size = new System.Drawing.Size(104, 18);
            this.txt_PLAN_UP_X.TabIndex = 58;
            this.txt_PLAN_UP_X.Text = "999999";
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.Control;
            this.textBox41.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox41.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox41.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox41.Location = new System.Drawing.Point(0, 0);
            this.textBox41.Margin = new System.Windows.Forms.Padding(2);
            this.textBox41.Name = "textBox41";
            this.textBox41.ReadOnly = true;
            this.textBox41.Size = new System.Drawing.Size(104, 18);
            this.textBox41.TabIndex = 57;
            this.textBox41.Text = "起吊X  ";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.txt_ORDER_ID);
            this.panel11.Controls.Add(this.textBox40);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 313);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(214, 25);
            this.panel11.TabIndex = 10;
            // 
            // txt_ORDER_ID
            // 
            this.txt_ORDER_ID.BackColor = System.Drawing.Color.White;
            this.txt_ORDER_ID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ORDER_ID.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_ORDER_ID.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ORDER_ID.Location = new System.Drawing.Point(104, 0);
            this.txt_ORDER_ID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ORDER_ID.Name = "txt_ORDER_ID";
            this.txt_ORDER_ID.ReadOnly = true;
            this.txt_ORDER_ID.Size = new System.Drawing.Size(104, 18);
            this.txt_ORDER_ID.TabIndex = 58;
            this.txt_ORDER_ID.Text = "999999";
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.Color.White;
            this.textBox40.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox40.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox40.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox40.Location = new System.Drawing.Point(0, 0);
            this.textBox40.Margin = new System.Windows.Forms.Padding(2);
            this.textBox40.Name = "textBox40";
            this.textBox40.ReadOnly = true;
            this.textBox40.Size = new System.Drawing.Size(104, 18);
            this.textBox40.TabIndex = 57;
            this.textBox40.Text = "指令号  ";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txt_CLAMP_WIDTH_ACT);
            this.panel10.Controls.Add(this.textBox39);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 282);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(214, 25);
            this.panel10.TabIndex = 9;
            // 
            // txt_CLAMP_WIDTH_ACT
            // 
            this.txt_CLAMP_WIDTH_ACT.BackColor = System.Drawing.SystemColors.Control;
            this.txt_CLAMP_WIDTH_ACT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CLAMP_WIDTH_ACT.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_CLAMP_WIDTH_ACT.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_CLAMP_WIDTH_ACT.Location = new System.Drawing.Point(104, 0);
            this.txt_CLAMP_WIDTH_ACT.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CLAMP_WIDTH_ACT.Name = "txt_CLAMP_WIDTH_ACT";
            this.txt_CLAMP_WIDTH_ACT.ReadOnly = true;
            this.txt_CLAMP_WIDTH_ACT.Size = new System.Drawing.Size(104, 18);
            this.txt_CLAMP_WIDTH_ACT.TabIndex = 58;
            this.txt_CLAMP_WIDTH_ACT.Text = "999999";
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.Control;
            this.textBox39.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox39.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox39.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox39.Location = new System.Drawing.Point(0, 0);
            this.textBox39.Margin = new System.Windows.Forms.Padding(2);
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.Size = new System.Drawing.Size(104, 18);
            this.textBox39.TabIndex = 57;
            this.textBox39.Text = "夹钳开度  ";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.txt_ROTATE_ANGLE_ACT);
            this.panel9.Controls.Add(this.textBox38);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 251);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(214, 25);
            this.panel9.TabIndex = 8;
            // 
            // txt_ROTATE_ANGLE_ACT
            // 
            this.txt_ROTATE_ANGLE_ACT.BackColor = System.Drawing.Color.White;
            this.txt_ROTATE_ANGLE_ACT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ROTATE_ANGLE_ACT.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_ROTATE_ANGLE_ACT.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ROTATE_ANGLE_ACT.Location = new System.Drawing.Point(104, 0);
            this.txt_ROTATE_ANGLE_ACT.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ROTATE_ANGLE_ACT.Name = "txt_ROTATE_ANGLE_ACT";
            this.txt_ROTATE_ANGLE_ACT.ReadOnly = true;
            this.txt_ROTATE_ANGLE_ACT.Size = new System.Drawing.Size(104, 18);
            this.txt_ROTATE_ANGLE_ACT.TabIndex = 58;
            this.txt_ROTATE_ANGLE_ACT.Text = "999999";
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.Color.White;
            this.textBox38.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox38.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox38.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox38.Location = new System.Drawing.Point(0, 0);
            this.textBox38.Margin = new System.Windows.Forms.Padding(2);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(104, 18);
            this.textBox38.TabIndex = 57;
            this.textBox38.Text = "夹钳转角  ";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txt_WEIGHT_LOADED);
            this.panel8.Controls.Add(this.textBox37);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 220);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(214, 25);
            this.panel8.TabIndex = 7;
            // 
            // txt_WEIGHT_LOADED
            // 
            this.txt_WEIGHT_LOADED.BackColor = System.Drawing.SystemColors.Control;
            this.txt_WEIGHT_LOADED.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_WEIGHT_LOADED.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_WEIGHT_LOADED.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_WEIGHT_LOADED.Location = new System.Drawing.Point(104, 0);
            this.txt_WEIGHT_LOADED.Margin = new System.Windows.Forms.Padding(2);
            this.txt_WEIGHT_LOADED.Name = "txt_WEIGHT_LOADED";
            this.txt_WEIGHT_LOADED.ReadOnly = true;
            this.txt_WEIGHT_LOADED.Size = new System.Drawing.Size(104, 18);
            this.txt_WEIGHT_LOADED.TabIndex = 58;
            this.txt_WEIGHT_LOADED.Text = "999999";
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.Control;
            this.textBox37.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox37.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox37.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox37.Location = new System.Drawing.Point(0, 0);
            this.textBox37.Margin = new System.Windows.Forms.Padding(2);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(104, 18);
            this.textBox37.TabIndex = 57;
            this.textBox37.Text = "重量   ";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.txt_ZSPEED);
            this.panel7.Controls.Add(this.textBox36);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 189);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(214, 25);
            this.panel7.TabIndex = 6;
            // 
            // txt_ZSPEED
            // 
            this.txt_ZSPEED.BackColor = System.Drawing.Color.White;
            this.txt_ZSPEED.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ZSPEED.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_ZSPEED.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ZSPEED.Location = new System.Drawing.Point(104, 0);
            this.txt_ZSPEED.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ZSPEED.Name = "txt_ZSPEED";
            this.txt_ZSPEED.ReadOnly = true;
            this.txt_ZSPEED.Size = new System.Drawing.Size(104, 18);
            this.txt_ZSPEED.TabIndex = 58;
            this.txt_ZSPEED.Text = "999999";
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.Color.White;
            this.textBox36.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox36.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox36.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox36.Location = new System.Drawing.Point(0, 0);
            this.textBox36.Margin = new System.Windows.Forms.Padding(2);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(104, 18);
            this.textBox36.TabIndex = 57;
            this.textBox36.Text = "升降速度  ";
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txt_YSPEED);
            this.panel6.Controls.Add(this.textBox34);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 158);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(214, 25);
            this.panel6.TabIndex = 5;
            // 
            // txt_YSPEED
            // 
            this.txt_YSPEED.BackColor = System.Drawing.SystemColors.Control;
            this.txt_YSPEED.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_YSPEED.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_YSPEED.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_YSPEED.Location = new System.Drawing.Point(104, 0);
            this.txt_YSPEED.Margin = new System.Windows.Forms.Padding(2);
            this.txt_YSPEED.Name = "txt_YSPEED";
            this.txt_YSPEED.ReadOnly = true;
            this.txt_YSPEED.Size = new System.Drawing.Size(104, 18);
            this.txt_YSPEED.TabIndex = 58;
            this.txt_YSPEED.Text = "999999";
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.Control;
            this.textBox34.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox34.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox34.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox34.Location = new System.Drawing.Point(0, 0);
            this.textBox34.Margin = new System.Windows.Forms.Padding(2);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(104, 18);
            this.textBox34.TabIndex = 57;
            this.textBox34.Text = "小车速度  ";
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.panel48);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 127);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(214, 25);
            this.panel5.TabIndex = 4;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.txt_XSPEED);
            this.panel48.Controls.Add(this.textBox35);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel48.Location = new System.Drawing.Point(0, 0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(214, 25);
            this.panel48.TabIndex = 5;
            // 
            // txt_XSPEED
            // 
            this.txt_XSPEED.BackColor = System.Drawing.Color.White;
            this.txt_XSPEED.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_XSPEED.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_XSPEED.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_XSPEED.Location = new System.Drawing.Point(104, 0);
            this.txt_XSPEED.Margin = new System.Windows.Forms.Padding(2);
            this.txt_XSPEED.Name = "txt_XSPEED";
            this.txt_XSPEED.ReadOnly = true;
            this.txt_XSPEED.Size = new System.Drawing.Size(104, 18);
            this.txt_XSPEED.TabIndex = 58;
            this.txt_XSPEED.Text = "999999";
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.Color.White;
            this.textBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox35.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox35.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox35.Location = new System.Drawing.Point(0, 0);
            this.textBox35.Margin = new System.Windows.Forms.Padding(2);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(104, 18);
            this.textBox35.TabIndex = 56;
            this.textBox35.Text = "大车速度  ";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txt_ZACT);
            this.panel4.Controls.Add(this.textBox33);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 96);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(214, 25);
            this.panel4.TabIndex = 3;
            // 
            // txt_ZACT
            // 
            this.txt_ZACT.BackColor = System.Drawing.SystemColors.Control;
            this.txt_ZACT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ZACT.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_ZACT.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ZACT.Location = new System.Drawing.Point(104, 0);
            this.txt_ZACT.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ZACT.Name = "txt_ZACT";
            this.txt_ZACT.ReadOnly = true;
            this.txt_ZACT.Size = new System.Drawing.Size(104, 18);
            this.txt_ZACT.TabIndex = 58;
            this.txt_ZACT.Text = "999999";
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.SystemColors.Control;
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox33.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox33.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox33.Location = new System.Drawing.Point(0, 0);
            this.textBox33.Margin = new System.Windows.Forms.Padding(2);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(104, 18);
            this.textBox33.TabIndex = 57;
            this.textBox33.Text = "Z  ";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.txt_YACT);
            this.panel3.Controls.Add(this.textBox32);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 65);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(214, 25);
            this.panel3.TabIndex = 2;
            // 
            // txt_YACT
            // 
            this.txt_YACT.BackColor = System.Drawing.Color.White;
            this.txt_YACT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_YACT.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_YACT.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_YACT.Location = new System.Drawing.Point(104, 0);
            this.txt_YACT.Margin = new System.Windows.Forms.Padding(2);
            this.txt_YACT.Name = "txt_YACT";
            this.txt_YACT.ReadOnly = true;
            this.txt_YACT.Size = new System.Drawing.Size(104, 18);
            this.txt_YACT.TabIndex = 58;
            this.txt_YACT.Text = "999999";
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.Color.White;
            this.textBox32.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox32.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox32.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox32.Location = new System.Drawing.Point(0, 0);
            this.textBox32.Margin = new System.Windows.Forms.Padding(2);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(104, 18);
            this.textBox32.TabIndex = 57;
            this.textBox32.Text = "Y  ";
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txt_XACT);
            this.panel2.Controls.Add(this.textBox31);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 34);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(214, 25);
            this.panel2.TabIndex = 1;
            // 
            // txt_XACT
            // 
            this.txt_XACT.BackColor = System.Drawing.SystemColors.Control;
            this.txt_XACT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_XACT.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_XACT.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_XACT.Location = new System.Drawing.Point(104, 0);
            this.txt_XACT.Margin = new System.Windows.Forms.Padding(2);
            this.txt_XACT.Name = "txt_XACT";
            this.txt_XACT.ReadOnly = true;
            this.txt_XACT.Size = new System.Drawing.Size(104, 18);
            this.txt_XACT.TabIndex = 58;
            this.txt_XACT.Text = "999999";
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.SystemColors.Control;
            this.textBox31.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox31.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox31.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox31.Location = new System.Drawing.Point(0, 0);
            this.textBox31.Margin = new System.Windows.Forms.Padding(2);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(104, 18);
            this.textBox31.TabIndex = 57;
            this.textBox31.Text = "X  ";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.txt_CONTROL_MODE);
            this.panel1.Controls.Add(this.textBox30);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 25);
            this.panel1.TabIndex = 0;
            // 
            // txt_CONTROL_MODE
            // 
            this.txt_CONTROL_MODE.BackColor = System.Drawing.Color.White;
            this.txt_CONTROL_MODE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CONTROL_MODE.Dock = System.Windows.Forms.DockStyle.Left;
            this.txt_CONTROL_MODE.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_CONTROL_MODE.Location = new System.Drawing.Point(104, 0);
            this.txt_CONTROL_MODE.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CONTROL_MODE.Name = "txt_CONTROL_MODE";
            this.txt_CONTROL_MODE.ReadOnly = true;
            this.txt_CONTROL_MODE.Size = new System.Drawing.Size(104, 18);
            this.txt_CONTROL_MODE.TabIndex = 57;
            this.txt_CONTROL_MODE.Text = "999999";
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.Color.White;
            this.textBox30.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox30.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox30.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox30.Location = new System.Drawing.Point(0, 0);
            this.textBox30.Margin = new System.Windows.Forms.Padding(2);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(104, 18);
            this.textBox30.TabIndex = 56;
            this.textBox30.Text = "模式   ";
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.text_CraneNO);
            this.panel24.Location = new System.Drawing.Point(3, 3);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(144, 31);
            this.panel24.TabIndex = 1;
            // 
            // text_CraneNO
            // 
            this.text_CraneNO.BackColor = System.Drawing.SystemColors.Control;
            this.text_CraneNO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_CraneNO.Dock = System.Windows.Forms.DockStyle.Left;
            this.text_CraneNO.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_CraneNO.Location = new System.Drawing.Point(0, 0);
            this.text_CraneNO.Margin = new System.Windows.Forms.Padding(2);
            this.text_CraneNO.Name = "text_CraneNO";
            this.text_CraneNO.ReadOnly = true;
            this.text_CraneNO.Size = new System.Drawing.Size(104, 23);
            this.text_CraneNO.TabIndex = 59;
            this.text_CraneNO.Text = "999999";
            // 
            // panel25
            // 
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(153, 3);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(220, 31);
            this.panel25.TabIndex = 2;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.cmd_Auto);
            this.panel26.Controls.Add(this.panel50);
            this.panel26.Controls.Add(this.cmd_Manu);
            this.panel26.Location = new System.Drawing.Point(3, 670);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(144, 69);
            this.panel26.TabIndex = 3;
            // 
            // cmd_Auto
            // 
            this.cmd_Auto.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmd_Auto.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmd_Auto.Location = new System.Drawing.Point(78, 0);
            this.cmd_Auto.Name = "cmd_Auto";
            this.cmd_Auto.Size = new System.Drawing.Size(66, 69);
            this.cmd_Auto.TabIndex = 5;
            this.cmd_Auto.Text = "自动";
            this.cmd_Auto.UseVisualStyleBackColor = true;
            this.cmd_Auto.Click += new System.EventHandler(this.cmd_Auto_Click);
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel50.Location = new System.Drawing.Point(64, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(14, 69);
            this.panel50.TabIndex = 4;
            // 
            // cmd_Manu
            // 
            this.cmd_Manu.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmd_Manu.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmd_Manu.Location = new System.Drawing.Point(0, 0);
            this.cmd_Manu.Name = "cmd_Manu";
            this.cmd_Manu.Size = new System.Drawing.Size(64, 69);
            this.cmd_Manu.TabIndex = 3;
            this.cmd_Manu.Text = "手动";
            this.cmd_Manu.UseVisualStyleBackColor = true;
            this.cmd_Manu.Click += new System.EventHandler(this.cmd_Manu_Click);
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.cmd_Reset);
            this.panel27.Controls.Add(this.panel49);
            this.panel27.Controls.Add(this.cmd_EmergencyStop);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(153, 670);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(220, 69);
            this.panel27.TabIndex = 4;
            // 
            // cmd_Reset
            // 
            this.cmd_Reset.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmd_Reset.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmd_Reset.Location = new System.Drawing.Point(154, 0);
            this.cmd_Reset.Name = "cmd_Reset";
            this.cmd_Reset.Size = new System.Drawing.Size(68, 69);
            this.cmd_Reset.TabIndex = 7;
            this.cmd_Reset.Text = "复位";
            this.cmd_Reset.UseVisualStyleBackColor = true;
            this.cmd_Reset.Click += new System.EventHandler(this.cmd_Reset_Click);
            // 
            // panel49
            // 
            this.panel49.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel49.Location = new System.Drawing.Point(127, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(27, 69);
            this.panel49.TabIndex = 6;
            // 
            // cmd_EmergencyStop
            // 
            this.cmd_EmergencyStop.BackColor = System.Drawing.Color.Brown;
            this.cmd_EmergencyStop.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmd_EmergencyStop.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmd_EmergencyStop.Location = new System.Drawing.Point(0, 0);
            this.cmd_EmergencyStop.Name = "cmd_EmergencyStop";
            this.cmd_EmergencyStop.Size = new System.Drawing.Size(127, 69);
            this.cmd_EmergencyStop.TabIndex = 5;
            this.cmd_EmergencyStop.Text = "紧急停止";
            this.cmd_EmergencyStop.UseVisualStyleBackColor = false;
            this.cmd_EmergencyStop.Click += new System.EventHandler(this.cmd_EmergencyStop_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel21, 0, 19);
            this.tableLayoutPanel3.Controls.Add(this.panel22, 0, 18);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 20;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // panel21
            // 
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(3, 383);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(194, 14);
            this.panel21.TabIndex = 19;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(3, 363);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(194, 14);
            this.panel22.TabIndex = 18;
            // 
            // panel23
            // 
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(3, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(194, 20);
            this.panel23.TabIndex = 17;
            // 
            // timer_AutoReset
            // 
            this.timer_AutoReset.Interval = 3000;
            this.timer_AutoReset.Tick += new System.EventHandler(this.timer_AutoReset_Tick);
            // 
            // ConCraneStatusPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ConCraneStatusPanel";
            this.Size = new System.Drawing.Size(376, 742);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox light_EMG_STOP;
        private System.Windows.Forms.TextBox light_HAS_COIL;
        private System.Windows.Forms.TextBox light_ZDIR_N;
        private System.Windows.Forms.TextBox light_ZDIR_P;
        private System.Windows.Forms.TextBox light_YDIR_N;
        private System.Windows.Forms.TextBox light_YDIR_P;
        private System.Windows.Forms.TextBox light_XDIR_N;
        private System.Windows.Forms.TextBox light_XDIR_P;
        private System.Windows.Forms.TextBox light_TASK_EXCUTING;
        private System.Windows.Forms.TextBox light_ASK_PLAN;
        private System.Windows.Forms.TextBox light_CONTROL_MODE;
        private System.Windows.Forms.TextBox light_READY;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox txt_XSPEED;
        private System.Windows.Forms.TextBox txt_ZACT;
        private System.Windows.Forms.TextBox txt_YACT;
        private System.Windows.Forms.TextBox txt_XACT;
        private System.Windows.Forms.TextBox txt_CONTROL_MODE;
        private System.Windows.Forms.TextBox txt_CRANE_STATUS_DESC;
        private System.Windows.Forms.TextBox txt_CRANE_STATUS;
        private System.Windows.Forms.TextBox txt_PLAN_DOWN_Z;
        private System.Windows.Forms.TextBox txt_PLAN_DOWN_Y;
        private System.Windows.Forms.TextBox txt_PLAN_DOWN_X;
        private System.Windows.Forms.TextBox txt_PLAN_UP_Z;
        private System.Windows.Forms.TextBox txt_PLAN_UP_Y;
        private System.Windows.Forms.TextBox txt_PLAN_UP_X;
        private System.Windows.Forms.TextBox txt_ORDER_ID;
        private System.Windows.Forms.TextBox txt_CLAMP_WIDTH_ACT;
        private System.Windows.Forms.TextBox txt_ROTATE_ANGLE_ACT;
        private System.Windows.Forms.TextBox txt_WEIGHT_LOADED;
        private System.Windows.Forms.TextBox txt_ZSPEED;
        private System.Windows.Forms.TextBox txt_YSPEED;
        private System.Windows.Forms.Button cmd_Manu;
        private System.Windows.Forms.Button cmd_EmergencyStop;
        private System.Windows.Forms.Button cmdDownLoadPlan;
        private System.Windows.Forms.TextBox text_CraneNO;
        private System.Windows.Forms.Button cmd_Reset;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Button cmd_Auto;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.TextBox txt_HeartBeat;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button cmdComputerOrderSetting;
        private System.Windows.Forms.Timer timer_AutoReset;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnEvade;
        private System.Windows.Forms.TextBox txt_Y_e;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox txt_X_e;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txt_R_e;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox txt_Z_e;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox TXT_TEMPERATURE;
        private System.Windows.Forms.TextBox textBox2;
    }
}
